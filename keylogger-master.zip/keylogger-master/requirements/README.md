# Installer files
Here are some older files for installing the required Python packages. (Especially if you are a Windows user!)
