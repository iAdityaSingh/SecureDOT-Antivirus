# Suriyaa's Keylogger 
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com) [![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg?style=flat-square)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UZRFM579K6FL2&source=url)

> A **simple python keylogger** (for educational purpose) built by [Suriyaa](https://about.suriyaa.tk).

![I found an Open Source Keylogger from Suriyaa on GitHub](https://cloud.githubusercontent.com/assets/5073946/19219911/c95ca976-8e20-11e6-9250-e73cfb5c7c75.jpg)


## Before you start...
Please read these files first before starting:

* [INSTALL.md](INSTALL.md) - How to use the program
* [CONTRIBUTING.md](.github/CONTRIBUTING.md) - Pull requests are welcome!

## Legal Disclaimer
The usage of this keylogger project for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. The developers behind the project assume no liability and are not responsible for any misuse or damage caused by this program.

## Code of Conduct
In order to have a more open and welcoming community, [Suriyaa](https://github.com/suriyaa) adheres to a [code of conduct](CODE_OF_CONDUCT.md) adapted from the [Bunto code of conduct](https://github.com/bunto/bunto/blob/master/CONDUCT.markdown).

Please adhere to this code of conduct in any interactions you have in the GitHub community. It is strictly enforced on all official repositories, websites, and resources of [Suriyaa](https://github.com/suriyaa). If you encounter someone violating these terms, please let a maintainer ([@suriyaa](https://github.com/suriyaa)) know and he will address it as soon as possible.

## License
You can find some legal blah blah blah... here: [LICENSE.md](LICENSE.md).

## Donate
If this project brings value to you, you can give me a cup of coffee. :-)

- [Donation website](https://blog.suriyaa.tk/donate/)
- [via GitHub Sponsors](https://github.com/sponsors/suriyaa)
- With [Bitcoin](https://about.suriyaa.tk/bitcoin-signature.txt) (or with a [cryptocurrency](https://commerce.coinbase.com/checkout/29b88d93-5fc3-40f5-a11c-ab8def95e3dd) of your choice)
- With [PayPal](https://www.paypal.me/suriyaasundararuban) in any fiat currency:

[![Donate with PayPal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UZRFM579K6FL2&source=url)

## Star History
[![Star History Chart](https://api.star-history.com/svg?repos=suriyaa/keylogger&type=Date)](https://star-history.com/#suriyaa/keylogger&Date)
