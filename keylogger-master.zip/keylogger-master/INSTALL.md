# Installation Guide
> This is the **Installation Guide** file for [the keylogger project](https://github.com/suriyaa/keylogger).

## Requirements
 - Any operating system (For running `*.bat` files please use [Windows](http://windows.microsoft.com/en-US/windows/home)
 - [Python 2.7 (or higher)](https://www.python.org/) (The code has been tested with Python version `2.7.10`.)
 - some programs (e.g. a browser or a editor)

## Installation steps
 1. Install Python on your computer
 2. [Download](https://github.com/suriyaa/keylogger/archive/master.zip) the latest version of this repository
 3. Extract the files (Recommended software: [7-Zip](http://www.7-zip.org) or [WinRAR](http://www.rarlab.com))
 4. Update the keylogger files with the correct file paths.
 5. Connect your `*.pyw` and `*.bat` files with an `*.exe` file of a program
 6. Run the keylogger in the background
 7. Done!
